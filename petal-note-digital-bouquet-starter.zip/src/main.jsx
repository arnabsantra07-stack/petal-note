import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { Flower2, Heart, Sparkles, ArrowLeft, ArrowRight, Copy, Share2, RotateCcw, Menu, X, Mail, Leaf } from "lucide-react";
import "./styles.css";

const FLOWERS = [
  { id: "rose", name: "Rose", emoji: "🌹", color: "#c85e70" },
  { id: "tulip", name: "Tulip", emoji: "🌷", color: "#e78a9d" },
  { id: "sunflower", name: "Sunflower", emoji: "🌻", color: "#e6b348" },
  { id: "daisy", name: "Daisy", emoji: "🌼", color: "#f4d8a2" },
  { id: "cherry", name: "Cherry blossom", emoji: "🌸", color: "#ef9cb4" },
  { id: "bouquet", name: "Mixed blooms", emoji: "💐", color: "#c98eb8" },
  { id: "lavender", name: "Lavender", emoji: "🪻", color: "#a99bd7" },
  { id: "hibiscus", name: "Hibiscus", emoji: "🌺", color: "#e77983" },
  { id: "white", name: "White flower", emoji: "🤍", color: "#e9dfd2" }
];
const DEFAULT = {
  recipient: "Someone special",
  sender: "Someone who cares",
  title: "A little bouquet for you",
  message: "I wanted to send you something small to remind you how special you are. I hope this little bouquet brings a smile to your face and makes your day feel a little softer and brighter. You deserve beautiful things, today and always. 🌷",
  flowers: ["rose", "tulip", "daisy"],
  theme: "blush"
};
const getFlower = id => FLOWERS.find(f => f.id === id) || FLOWERS[0];

function encode(data) {
  const bytes = new TextEncoder().encode(JSON.stringify(data));
  let binary = "";
  bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function decode(value) {
  try {
    const base = value.replace(/-/g, "+").replace(/_/g, "/");
    const binary = atob(base);
    const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
    const parsed = JSON.parse(new TextDecoder().decode(bytes));
    if (parsed && Array.isArray(parsed.flowers) && typeof parsed.message === "string") return { ...DEFAULT, ...parsed };
  } catch {}
  return null;
}
function BouquetArt({ flowers = DEFAULT.flowers, large = false }) {
  const selected = flowers.length ? flowers : DEFAULT.flowers;
  return <div className={`bouquet-art ${large ? "large" : ""}`} aria-label="Illustrated bouquet">
    <div className="paper-wrap"></div>
    <div className="stems">{selected.slice(0, 7).map((id, i) =>
      <span key={id + i} className="stem" style={{ "--i": i, "--n": Math.min(selected.length, 7) }}>╱</span>)}</div>
    <div className="blooms">{selected.slice(0, 7).map((id, i) =>
      <span key={id + i} className="bloom" style={{ "--i": i, "--n": Math.min(selected.length, 7), "--tilt": `${(i % 2 ? 1 : -1) * (8 + i * 2)}deg` }}>{getFlower(id).emoji}</span>)}</div>
    <div className="bouquet-ribbon"></div>
    <div className="floating-petal petal-one">✿</div><div className="floating-petal petal-two">♡</div><div className="floating-petal petal-three">✧</div>
  </div>;
}
function App() {
  const [bouquet, setBouquet] = useState(DEFAULT);
  const [step, setStep] = useState(0);
  const [opened, setOpened] = useState(false);
  const [sharedView, setSharedView] = useState(false);
  const [notice, setNotice] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  useEffect(() => {
    const shared = window.location.hash.startsWith("#b=");
    if (shared) {
      const data = decode(window.location.hash.slice(3));
      if (data) { setBouquet(data); setSharedView(true); setOpened(false); }
    }
  }, []);
  const update = (key, value) => setBouquet(prev => ({ ...prev, [key]: value }));
  const toggleFlower = id => update("flowers", bouquet.flowers.includes(id)
    ? bouquet.flowers.filter(f => f !== id)
    : [...bouquet.flowers, id].slice(0, 7));
  const makeLink = () => {
    const url = `${window.location.origin}${window.location.pathname}#b=${encode(bouquet)}`;
    setShareUrl(url);
    return url;
  };
  const copyLink = async () => {
    const url = makeLink();
    try {
      await navigator.clipboard.writeText(url);
      setNotice("Your bouquet link is copied!");
    } catch {
      setNotice("Copy this link: " + url);
    }
  };
  const share = async () => {
    const url = makeLink();
    if (navigator.share) {
      try { await navigator.share({ title: `A bouquet for ${bouquet.recipient}`, text: bouquet.title, url }); }
      catch {}
    } else await copyLink();
  };
  const reset = () => {
    setBouquet(DEFAULT); setStep(0); setOpened(false); setSharedView(false);
    window.history.replaceState(null, "", window.location.pathname);
  };
  const steps = ["Flowers", "Your letter", "Preview"];
  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={reset} aria-label="Petal Note home"><span className="brand-mark"><Flower2 size={21}/></span><span>petal note</span></button>
      <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X/> : <Menu/>}</button>
      <nav className={menuOpen ? "nav open" : "nav"}>
        <a href="#how" onClick={() => setMenuOpen(false)}>How it works</a>
        <button className="text-button" onClick={reset}>Start fresh</button>
      </nav>
    </header>

    {sharedView ? <main className="gift-page">
      {!opened ? <section className="gift-intro fade-in">
        <div className="eyebrow"><Sparkles size={14}/> A little something for you</div>
        <h1>{bouquet.title || "A little bouquet for you"}</h1>
        <p className="intro-copy">Made with care, just for <em>{bouquet.recipient || "you"}</em>.</p>
        <BouquetArt flowers={bouquet.flowers} large/>
        <button className="primary-button" onClick={() => setOpened(true)}>Open your letter <Heart size={16} fill="currentColor"/></button>
        <p className="tiny-note">A tiny bouquet, a little note, and lots of warmth.</p>
      </section> : <section className="letter-reveal fade-in">
        <div className="letter-card">
          <div className="letter-flower">✿</div><p className="letter-kicker">A note for {bouquet.recipient || "you"}</p>
          <h1>Dear {bouquet.recipient || "you"},</h1>
          <p className="letter-body">{bouquet.message}</p>
          <div className="letter-signoff">With warmth, <span>{bouquet.sender || "Someone who cares"}</span></div>
          <div className="letter-bottom">✦ made just for you ✦</div>
        </div>
        <button className="outline-button" onClick={() => setOpened(false)}><ArrowLeft size={16}/> Back to bouquet</button>
      </section>}
    </main> : <main>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={14}/> A thoughtful little gift</div>
          <h1>Some feelings<br/><em>deserve flowers.</em></h1>
          <p className="hero-description">Create a digital bouquet, tuck a heartfelt letter inside, and send a little happiness to someone special.</p>
          <button className="primary-button" onClick={() => { setSharedView(false); setStep(0); document.getElementById("builder")?.scrollIntoView({behavior:"smooth"}); }}>Create your bouquet <ArrowRight size={17}/></button>
          <div className="hero-foot"><span><Heart size={14}/> made with care</span><span><Leaf size={14}/> no app needed</span></div>
        </div>
        <div className="hero-art-wrap"><div className="sun-glow"></div><BouquetArt flowers={bouquet.flowers} large/><div className="floating-note">for someone<br/><em>very special</em> ♡</div></div>
      </section>

      <section className="builder-section" id="builder">
        <div className="section-heading"><div className="eyebrow">MAKE IT YOURS</div><h2>A bouquet from the heart</h2><p>Choose a few blooms and write the words you want them to keep.</p></div>
        <div className="builder-card">
          <div className="stepper">{steps.map((s, i) => <button key={s} onClick={() => setStep(i)} className={step === i ? "step active" : "step"}><span>{i+1}</span>{s}</button>)}</div>
          {step === 0 && <div className="builder-content fade-in">
            <h3>Choose your flowers</h3><p className="subtext">Pick up to seven blooms for your little arrangement.</p>
            <div className="flower-grid">{FLOWERS.map(f => <button key={f.id} onClick={() => toggleFlower(f.id)} className={`flower-option ${bouquet.flowers.includes(f.id) ? "selected" : ""}`}><span className="flower-emoji">{f.emoji}</span><span>{f.name}</span>{bouquet.flowers.includes(f.id) && <span className="check">✓</span>}</button>)}</div>
            <div className="step-actions"><span className="selection-count">{bouquet.flowers.length} selected</span><button className="primary-button" onClick={() => setStep(1)}>Write your letter <ArrowRight size={16}/></button></div>
          </div>}
          {step === 1 && <div className="builder-content fade-in">
            <h3>Add a little letter</h3><p className="subtext">Make it sound like you. Simple and sincere is beautiful.</p>
            <div className="form-grid"><label>For someone special<input value={bouquet.recipient} maxLength={50} onChange={e => update("recipient", e.target.value)} placeholder="Their name or nickname"/></label><label>From<input value={bouquet.sender} maxLength={50} onChange={e => update("sender", e.target.value)} placeholder="Your name or nickname"/></label><label className="full">Letter title<input value={bouquet.title} maxLength={70} onChange={e => update("title", e.target.value)} placeholder="A little bouquet for you"/></label><label className="full">Your personal message<textarea rows="7" maxLength={1400} value={bouquet.message} onChange={e => update("message", e.target.value)} placeholder="Write something kind and meaningful..."/></label></div>
            <div className="step-actions"><button className="outline-button" onClick={() => setStep(0)}><ArrowLeft size={16}/> Flowers</button><button className="primary-button" onClick={() => setStep(2)}>Preview bouquet <ArrowRight size={16}/></button></div>
          </div>}
          {step === 2 && <div className="builder-content preview-content fade-in">
            <div className="preview-layout"><div className="preview-art"><BouquetArt flowers={bouquet.flowers} large/></div><div className="preview-copy"><div className="eyebrow">YOUR LITTLE GIFT</div><h3>{bouquet.title}</h3><p>For <strong>{bouquet.recipient || "someone special"}</strong></p><div className="message-snippet">“{bouquet.message.slice(0, 190)}{bouquet.message.length > 190 ? "…" : ""}”</div><p className="signature">With warmth, {bouquet.sender || "Someone who cares"}</p></div></div>
            <div className="step-actions"><button className="outline-button" onClick={() => setStep(1)}><ArrowLeft size={16}/> Edit letter</button><button className="primary-button" onClick={() => { const url = makeLink(); setNotice("Your unique link is ready. Copy it or share it below."); }}><Share2 size={16}/> Create share link</button></div>
            {shareUrl && <div className="share-panel"><div className="share-panel-title"><Heart size={16}/> Your bouquet is ready</div><p>Anyone with this link can open your bouquet on a phone, tablet or computer.</p><div className="link-row"><input readOnly value={shareUrl} aria-label="Share link"/><button className="copy-button" onClick={copyLink} aria-label="Copy link"><Copy size={17}/></button></div><button className="primary-button share-wide" onClick={share}><Share2 size={16}/> Share bouquet</button><p className="privacy-note">This starter stores the bouquet details inside the link. Keep the link private if the message is personal.</p></div>}
          </div>}
        </div>
      </section>
      <section className="how-section" id="how"><div className="section-heading"><div className="eyebrow">THOUGHTFUL, NOT COMPLICATED</div><h2>Little things make a big feeling</h2></div><div className="how-grid"><article><span className="how-icon"><Flower2/></span><h3>Choose the blooms</h3><p>Mix and match flowers to create a bouquet that feels like them.</p></article><article><span className="how-icon"><Mail/></span><h3>Write from the heart</h3><p>Add a name, a sign-off, and a note they can open when they like.</p></article><article><span className="how-icon"><Share2/></span><h3>Send a little joy</h3><p>Create a unique link and share it in a message, wherever they are.</p></article></div></section>
    </main>}
    <footer><div className="footer-brand"><Flower2 size={17}/> petal note</div><p>Little flowers. Thoughtful words. A moment to keep.</p><button onClick={reset} className="footer-reset"><RotateCcw size={13}/> Make another bouquet</button></footer>
    {notice && <div className="toast" role="status"><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss"><X size={15}/></button></div>}
  </div>;
}
createRoot(document.getElementById("root")).render(<App/>);
